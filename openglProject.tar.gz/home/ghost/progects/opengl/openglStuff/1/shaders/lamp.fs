#version 330 core
out vec4 FragColor;

void main()
{
    FragColor = vec4(1.0); // устанавливаем значения всех 4-х компонентов вектора равным 1.0
}
